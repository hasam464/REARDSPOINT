<?php

    /*!
	 * POCKET v4
	 *
	 * http://www.droidoxy.com
	 * support@droidoxy.com
	 *
	 * Copyright 2020 DroidOXY ( http://www.droidoxy.com )
	 */
	
$B = array();

//  Database details

$B['DB_HOST'] = "_DB_HOST_";        //localhost or your Database host
$B['DB_NAME'] = "_DB_NAME_";        //your Database name
$B['DB_USER'] = "_DB_USER_";        //your Database user
$B['DB_PASS'] = "_DB_PASSWORD_";    //your Database password


// TimeZone - Uncomment the below and change it to your Local Timezone (optional)
// date_default_timezone_set('Asia/Kolkata');

$INSTALL_STATUS = "_INSTALL_STATUS_";

?>